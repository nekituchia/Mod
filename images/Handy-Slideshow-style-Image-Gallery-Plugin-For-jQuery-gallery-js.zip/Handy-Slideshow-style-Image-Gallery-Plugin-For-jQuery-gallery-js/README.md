jquery-gallery
========

jQuery-based gallery with keyboard navigation. Created by [Simon Sablowski](http://www.simsab.net).

Demo: [projects.simsab.net/jquery-gallery/example](http://projects.simsab.net/jquery-gallery/example)
